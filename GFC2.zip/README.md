<div align=center>
 
# 🚀 KATA DDOS V1 - Free DDoS Panel 🚀

# Get Username and pass at: https://link68.net/j4yHp0
# README ♥️
Thank you for using, please help me press a star button, thank you very much.<br>
One star = continuously updating multiple methods

# Info
- [x] Open Source
- [x] Powerful
- [x] Simple
- [x] Methods for Layer 4 and 7
- [x] Bypass (Cloudflare, OVH, NFO,...)  


# Setup
```sh
CentOS:
yum install git -y
yum install golang -y
yum install perl -y
yum install python2 -y
yum install python3 -y
yum install python3-pip -y
yum install nodejs -y
yum install npm -y

Debain, Ubuntu:
sudo apt-get install git -y
sudo apt-get install golang -y
sudo apt-get install perl -y
sudo apt-get install python3 -y
sudo apt-get install python2 -y
sudo apt-get install python3-pip -y
sudo apt-get install nodejs -y
sudo apt-get install npm -y

How to use: 
- Recommended in shell of google, azure,...
- Using vps with high speed will be stronger

git clone https://github.com/katavnnn/KATA-ddos-panel/
cd KATA-ddos-panel
npm i requests
npm i https-proxy-agent
npm i crypto-random-string
npm i events
npm i fs
npm i net
npm i cloudscraper
npm i request
npm i hcaptcha-solver
npm i randomstring
npm i cluster
npm i cloudflare-bypasser
pip install asciimatics
pip install pystyle
wget https://dl.google.com/linux/direct/google-chrome-stable_current_amd64.deb
apt-get install ./google-chrome-stable_current_amd64.deb
ulimit -n 999999
chmod 777 *
python3 main.py
```


# TOS:
```sh
Do not attack government pages (.gov/.gob), educational pages (.edu) or the United States Department of Defense (.mil), 
the creator is not responsible for the damage caused by the attacks. 
remember: you are responsible for the attacks since this tool was created for educational purposes
```

# CONTACT:
```sh
FB: fb.com/katavn.2006
Discord: katavnnn#8946
```
